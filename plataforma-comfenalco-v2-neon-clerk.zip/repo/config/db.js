// ============================================================
// config/db.js
// Cliente Neon (PostgreSQL serverless)
//
// INSTRUCCIONES:
// 1. Ve a https://neon.tech → Sign up (gratis, con GitHub)
// 2. New Project → nombre: plataforma-comfenalco
// 3. Dashboard → Connection string → copia la URL
//    Tiene este formato:
//    postgresql://user:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require
// 4. Pégala en NEON_URL abajo
// ============================================================

export const NEON_URL = 'postgresql://TU_USER:TU_PASSWORD@ep-xxx.aws.neon.tech/neondb?sslmode=require';

// ── Cliente HTTP para queries desde el navegador ─────────────
// Neon tiene un driver HTTP que funciona directo desde el frontend
// sin necesidad de servidor propio.
// Docs: https://neon.tech/docs/serverless/serverless-driver

import { neon } from 'https://esm.sh/@neondatabase/serverless@0.9.3';

export const sql = neon(NEON_URL);

// ── Helper genérico para queries ────────────────────────────
export const DB = {

  // Ejecutar una query con parámetros seguros (evita SQL injection)
  async query(queryStr, params = []) {
    try {
      const result = await sql(queryStr, params);
      return { data: result, error: null };
    } catch (err) {
      console.error('DB Error:', err.message);
      return { data: null, error: err.message };
    }
  },

  // Obtener un solo registro
  async one(queryStr, params = []) {
    const { data, error } = await this.query(queryStr, params);
    return { data: data?.[0] ?? null, error };
  },

  // Estadísticas generales (llama a la función PostgreSQL)
  async estadisticas() {
    return this.one('SELECT fn_estadisticas_generales() AS stats');
  },

  // Vacantes para la landing
  async vacantesRecientes(limite = 6) {
    return this.query(
      'SELECT * FROM fn_buscar_vacantes($1, NULL, NULL, NULL, NULL, NULL, $2, 0)',
      [null, limite]
    );
  },

  // Buscar vacantes con filtros
  async buscarVacantes({ texto = null, municipioId = null, limite = 10, offset = 0 } = {}) {
    return this.query(
      'SELECT * FROM fn_buscar_vacantes($1, $2, NULL, NULL, NULL, NULL, $3, $4)',
      [texto, municipioId, limite, offset]
    );
  },

  // Buscar candidatos (banco de HV)
  async buscarCandidatos({ municipioId = null, areaInteres = null, texto = null, limite = 20, offset = 0 } = {}) {
    return this.query(
      'SELECT * FROM fn_buscar_candidatos($1, NULL, $2, NULL, NULL, NULL, $3, $4, $5)',
      [municipioId, areaInteres, texto, limite, offset]
    );
  },

  // HV completa de un candidato
  async hvCompleta(candidatoId) {
    return this.one('SELECT fn_hv_completa($1) AS hv', [candidatoId]);
  },

  // Municipios para selects
  async municipios() {
    return this.query('SELECT * FROM municipios ORDER BY nombre');
  },

  // Indicadores para reportes
  async indicadoresPeriodo(fechaInicio, fechaFin, municipioId = null) {
    return this.one(
      'SELECT fn_indicadores_periodo($1, $2, $3) AS indicadores',
      [fechaInicio, fechaFin, municipioId]
    );
  }
};

export default DB;
